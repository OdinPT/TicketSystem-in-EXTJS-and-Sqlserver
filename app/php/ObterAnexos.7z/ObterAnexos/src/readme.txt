NV => Nova vers�o


VA => Vers�o Antiga


emailsNV 13-03 1340
se o ticket for mudado no hist�rico muda para os tickets.